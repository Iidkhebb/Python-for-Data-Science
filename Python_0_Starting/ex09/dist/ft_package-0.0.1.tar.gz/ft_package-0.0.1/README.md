# ft_package

A sample Python package for counting occurrences in a list.

## Installation

You can install ft_package via pip:

```bash
pip install ft_package
Usage
python
Copy code
from ft_package import count_in_list

print(count_in_list(["toto", "tata", "toto"], "toto"))  # Output: 2
print(count_in_list(["toto", "tata", "toto"], "tutu"))  # Output: 0
License
This project is licensed under the MIT License - see the LICENSE file for details.


LICENSE:
MIT License