from setuptools import setup, find_packages

setup(
    name='ft_package',
    version='0.0.1',
    description='A sample test package',
    author='iidkhebb',
    author_email='test@42.fr',
    url='https://github.com/iidkhebb/ft_package',
    license='MIT',
    packages=find_packages(),
)
